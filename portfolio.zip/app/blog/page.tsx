import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function BlogPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="mb-8 text-center text-3xl font-bold tracking-tighter sm:text-4xl">Blog</h1>
      <Card>
        <CardHeader>
          <CardTitle>Coming Soon</CardTitle>
          <CardDescription>Blog posts will be added here in the future.</CardDescription>
        </CardHeader>
        <CardContent>
          <p>Check back later for updates and new content!</p>
        </CardContent>
      </Card>
    </div>
  )
}


import { ArrowLeft } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"

export default function UnderwaterROVProject() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Navigation */}
        <div className="mb-8">
          <Link href="/">
            <Button variant="ghost" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Portfolio
            </Button>
          </Link>
        </div>

        {/* Project Header */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold tracking-tighter">Underwater ROV</h1>
          <p className="mt-4 text-xl text-muted-foreground">Duke Robotics Club - 2025 RoboSub Competition</p>
        </div>

        {/* Main Project Image */}
        <div className="relative mb-12 aspect-video w-full overflow-hidden rounded-lg">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Minibot%20render-8VNVx5cU7OnkLV89ePrNVPWApd0ElG.png"
            alt="Underwater ROV"
            fill
            className="object-cover"
            priority
          />
        </div>

        {/* Project Overview */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Project Overview</CardTitle>
            <CardDescription>Autonomous Underwater Vehicle Development</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Contributed to the development of an autonomous underwater ROV for the 2025 RoboSub competition. The robot
              is designed to operate independently underwater, completing various competition tasks through autonomous
              navigation and control.
            </p>
            <div className="mt-4">
              <h3 className="mb-2 font-semibold">Current Development</h3>
              <p className="text-muted-foreground">
                We are working on a case for the Minibot to further optimize its hydrodynamics by enclosing the two
                capsules. This enhancement will improve the ROV's underwater performance and efficiency.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Technical Contributions */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Technical Contributions</CardTitle>
            <CardDescription>Key Design Elements and Systems</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div>
                <h3 className="mb-2 font-semibold">Capsule Mounting System</h3>
                <p className="text-muted-foreground">
                  Designed the mounting system for the dual capsule configuration, incorporating:
                </p>
                <ul className="mt-2 list-inside list-disc space-y-2 text-muted-foreground">
                  <li>Secure attachment to the robot's backplate</li>
                  <li>SLS-printed nylon guides for precise capsule spacing</li>
                  <li>Waterproof sealing considerations</li>
                </ul>
              </div>
              <Separator />
              <div>
                <h3 className="mb-2 font-semibold">Structural Design</h3>
                <p className="text-muted-foreground">Developed the primary structural components:</p>
                <ul className="mt-2 list-inside list-disc space-y-2 text-muted-foreground">
                  <li>Side plates: Large enclosure panels providing structural integrity and protection</li>
                  <li>
                    Mounting bars: Cross-vehicle support with hexagonal bolt pattern for flexible component mounting
                  </li>
                  <li>Integration of modular mounting solutions for easy maintenance and upgrades</li>
                </ul>
              </div>
              <Separator />
              <div>
                <h3 className="mb-2 font-semibold">Hydrodynamic Analysis</h3>
                <p className="text-muted-foreground">
                  Conducted Computational Fluid Dynamics (CFD) analysis on the frame design to:
                </p>
                <ul className="mt-2 list-inside list-disc space-y-2 text-muted-foreground">
                  <li>Optimize hydrodynamic performance</li>
                  <li>Reduce drag coefficients</li>
                  <li>Improve overall efficiency of underwater movement</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Design Features */}
        <Card>
          <CardHeader>
            <CardTitle>Design Features</CardTitle>
            <CardDescription>Key Characteristics and Innovations</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 md:grid-cols-2">
              <div>
                <h3 className="mb-2 font-semibold">Structural Innovation</h3>
                <ul className="list-inside list-disc space-y-2 text-muted-foreground">
                  <li>Dual capsule design for separated systems</li>
                  <li>Modular mounting system for easy maintenance</li>
                  <li>Optimized weight distribution</li>
                </ul>
              </div>
              <div>
                <h3 className="mb-2 font-semibold">Performance Features</h3>
                <ul className="list-inside list-disc space-y-2 text-muted-foreground">
                  <li>Hydrodynamically optimized frame</li>
                  <li>Multiple thruster configuration</li>
                  <li>Robust waterproof enclosure system</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}


import { ArrowLeft } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function ModelRocketProject() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Navigation */}
        <div className="mb-8">
          <Link href="/">
            <Button variant="ghost" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Portfolio
            </Button>
          </Link>
        </div>

        {/* Project Header */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold tracking-tighter">Model Rocket Project</h1>
          <p className="mt-4 text-xl text-muted-foreground">Custom Rocket Design and Construction</p>
        </div>

        {/* Main Project Image */}
        <div className="relative mb-12 aspect-[3/4] max-w-lg mx-auto overflow-hidden rounded-lg">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_9461.JPG-3r8RBJdJFBiom8ObbaSZZSuqLZKdiB.jpeg"
            alt="Model Rocket"
            fill
            className="object-contain"
            priority
          />
        </div>

        {/* Project Overview */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Project Overview</CardTitle>
            <CardDescription>Custom Model Rocket Development</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              This project involved the design and construction of a custom model rocket, showcasing advanced features
              and innovative design elements. The rocket demonstrates precision engineering and attention to detail in
              small-scale aerospace projects.
            </p>
          </CardContent>
        </Card>

        {/* Design Features */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Design Features</CardTitle>
            <CardDescription>Key Components and Innovations</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="list-inside list-disc space-y-2 text-muted-foreground">
              <li>Custom-designed airframe for optimal aerodynamics</li>
              <li>Innovative fin assembly for stability during flight</li>
              <li>Modular design allowing for easy assembly and modification</li>
              <li>Integration of electronic systems for data collection (if applicable)</li>
            </ul>
          </CardContent>
        </Card>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Flight Testing</CardTitle>
            <CardDescription>Initial Launch and Lessons Learned</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              The first flight attempt encountered challenges when the engines failed to ignite. This experience
              provided valuable insights for subsequent launches and led to improvements in the ignition system
              reliability.
            </p>
          </CardContent>
        </Card>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Control System</CardTitle>
            <CardDescription>Active Stabilization Technology</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p className="text-muted-foreground">
                The rocket features an advanced closed-loop control system for fin guidance and stabilization:
              </p>
              <ul className="list-inside list-disc space-y-2 text-muted-foreground">
                <li>Arduino Uno microcontroller for real-time processing</li>
                <li>IMU (Inertial Measurement Unit) for attitude detection</li>
                <li>Individual fin control for pitch, yaw, and roll stability</li>
                <li>Closed-loop feedback system for precise flight corrections</li>
              </ul>
              <p className="text-muted-foreground">
                This active stabilization system continuously monitors the rocket's orientation and makes real-time
                adjustments to maintain stable flight characteristics across all axes.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Project Outcomes */}
        <Card>
          <CardHeader>
            <CardTitle>Project Outcomes</CardTitle>
            <CardDescription>Achievements and Learnings</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              This project provided valuable experience in aerospace engineering principles, including:
            </p>
            <ul className="mt-2 list-inside list-disc space-y-2 text-muted-foreground">
              <li>Application of aerodynamic concepts in practical design</li>
              <li>Understanding of propulsion systems and their integration</li>
              <li>Experience with lightweight, high-strength materials</li>
              <li>Development of skills in precision manufacturing and assembly</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}


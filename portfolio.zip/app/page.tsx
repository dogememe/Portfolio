import Link from "next/link"
import Image from "next/image"
import { Phone, Linkedin, Mail, Download } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section id="home" className="container mx-auto px-4 py-24 md:py-32">
        <div className="flex flex-col items-center text-center">
          <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl bg-gradient-to-r from-primary to-blue-600 bg-clip-text text-transparent">
            Niko Weaver
          </h1>
          <p className="mt-4 text-xl text-muted-foreground">Mechanical Engineering Student at Duke University</p>
          <div className="mt-6 flex gap-4">
            <div className="relative group">
              <a href="tel:+16178521905">
                <Button variant="outline" size="icon">
                  <Phone className="h-5 w-5" />
                  <span className="sr-only">Phone</span>
                </Button>
              </a>
              <span className="absolute -top-10 left-1/2 -translate-x-1/2 whitespace-nowrap rounded bg-primary px-2 py-1 text-white opacity-0 transition-opacity group-hover:opacity-100">
                617-852-1905
              </span>
            </div>
            <div className="relative group">
              <a href="https://www.linkedin.com/in/niko-weaver/" target="_blank" rel="noopener noreferrer">
                <Button variant="outline" size="icon">
                  <Linkedin className="h-5 w-5" />
                  <span className="sr-only">LinkedIn</span>
                </Button>
              </a>
              <span className="absolute -top-10 left-1/2 -translate-x-1/2 whitespace-nowrap rounded bg-primary px-2 py-1 text-white opacity-0 transition-opacity group-hover:opacity-100">
                linkedin.com/in/niko-weaver
              </span>
            </div>
            <div className="relative group">
              <a href="mailto:nikoweaver@gmail.com">
                <Button variant="outline" size="icon">
                  <Mail className="h-5 w-5" />
                  <span className="sr-only">Email</span>
                </Button>
              </a>
              <span className="absolute -top-10 left-1/2 -translate-x-1/2 whitespace-nowrap rounded bg-primary px-2 py-1 text-white opacity-0 transition-opacity group-hover:opacity-100">
                nikoweaver@gmail.com
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="container mx-auto px-4 py-16">
        <h2 className="mb-12 text-center text-3xl font-bold tracking-tighter sm:text-4xl">Engineering Projects</h2>
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-2">
          {/* UAV Project */}
          <Card className="overflow-hidden border-2 transition-all duration-300 hover:border-primary hover:shadow-lg hover:shadow-primary/50">
            <Link href="/uav-project">
              <div className="relative aspect-video">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Gallery1-f93eOiY7MMqX2tEa8wXSSmyR81S5Zi.png"
                  alt="UAV Design"
                  fill
                  className="object-cover transition-transform duration-300 hover:scale-105"
                />
              </div>
              <CardHeader>
                <CardTitle>UAV Design Project</CardTitle>
                <CardDescription>Aerodynamic UAV Design and Analysis</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Developed an advanced UAV design focusing on aerodynamic efficiency and performance optimization.
                  Granted $XXXX from the Duke University Colab grant.
                </p>
              </CardContent>
            </Link>
          </Card>

          {/* Underwater ROV Project */}
          <Card className="overflow-hidden border-2 transition-all duration-300 hover:border-primary hover:shadow-lg hover:shadow-primary/50">
            <Link href="/underwater-rov">
              <div className="relative aspect-video">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Minibot%20render-8VNVx5cU7OnkLV89ePrNVPWApd0ElG.png"
                  alt="Underwater ROV"
                  fill
                  className="object-cover transition-transform duration-300 hover:scale-105"
                />
              </div>
              <CardHeader>
                <CardTitle>Underwater ROV</CardTitle>
                <CardDescription>Duke Robotics Club - RoboSub Competition</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Designed key structural components and performed hydrodynamic analysis for an autonomous underwater
                  ROV for the Duke Robotics Club.
                </p>
                <Image
                  src="/duke-robotics-logo.png"
                  alt="Duke Robotics Club Logo"
                  width={50}
                  height={50}
                  className="mt-2"
                />
              </CardContent>
            </Link>
          </Card>

          {/* FRC Robot Project */}
          <Card className="overflow-hidden border-2 transition-all duration-300 hover:border-primary hover:shadow-lg hover:shadow-primary/50">
            <Link href="/frc-robot">
              <div className="relative aspect-video">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/3245bot.png-bvCoWHqQ7D1V0Ziw3oXpDPbieC9rdm.jpeg"
                  alt="FRC Robot"
                  fill
                  className="object-cover transition-transform duration-300 hover:scale-105"
                />
              </div>
              <CardHeader>
                <CardTitle>FRC Robotics Competition</CardTitle>
                <CardDescription>Team 3245 Competition Robot</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Led the mechanical design and construction of Team 3245's competition robot for the 2024 FRC season.
                </p>
              </CardContent>
            </Link>
          </Card>

          {/* Model Rocket Project */}
          <Card className="overflow-hidden border-2 transition-all duration-300 hover:border-primary hover:shadow-lg hover:shadow-primary/50">
            <Link href="/model-rocket">
              <div className="relative aspect-video">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_9461.JPG-3r8RBJdJFBiom8ObbaSZZSuqLZKdiB.jpeg"
                  alt="Model Rocket"
                  fill
                  className="object-cover transition-transform duration-300 hover:scale-105"
                />
              </div>
              <CardHeader>
                <CardTitle>Model Rocket Development</CardTitle>
                <CardDescription>Custom Rocket Design and Construction</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Designed and constructed a custom model rocket. Flown in the Bonneville Salt Flats, Utah, December
                  2023. Half of the engines ignited, resulting in an RUD (Rapid Unscheduled Disassembly).
                </p>
              </CardContent>
            </Link>
          </Card>
        </div>
      </section>

      {/* Resume Section */}
      <section id="resume" className="container mx-auto px-4 py-16">
        <h2 className="mb-8 text-center text-3xl font-bold tracking-tighter sm:text-4xl">Resume</h2>
        <div className="flex justify-center mb-4">
          <Button className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            Download Resume
          </Button>
        </div>
        <div className="aspect-[8.5/11] w-full max-w-3xl mx-auto">
          <iframe
            src="/path-to-your-resume.pdf#view=FitH"
            width="100%"
            height="100%"
            className="border-2 border-primary"
          ></iframe>
        </div>
      </section>
    </div>
  )
}


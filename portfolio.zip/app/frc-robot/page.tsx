import { ArrowLeft } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function FRCRobotProject() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Navigation */}
        <div className="mb-8">
          <Link href="/">
            <Button variant="ghost" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Portfolio
            </Button>
          </Link>
        </div>

        {/* Project Header */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold tracking-tighter">FRC Robot - Team 3245</h1>
          <p className="mt-4 text-xl text-muted-foreground">
            2024 FIRST Robotics Competition Robot Design and Development
          </p>
        </div>

        {/* Main Project Image */}
        <div className="relative mb-12 aspect-video w-full overflow-hidden rounded-lg">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/3245bot.png-bvCoWHqQ7D1V0Ziw3oXpDPbieC9rdm.jpeg"
            alt="FRC Robot"
            fill
            className="object-cover"
            priority
          />
        </div>

        {/* Project Role */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Project Role</CardTitle>
            <CardDescription>Leadership and Technical Contributions</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              As a captain of the team and mechanical lead in 2024, I was responsible for designing multiple major
              systems on the Robot. Most notably, I designed the shooter, pivot, and swerve Drivebase of the robot.
            </p>
          </CardContent>
        </Card>

        {/* Game Description */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>2024 FRC Game</CardTitle>
            <CardDescription>Crescendo - Shooting and Climbing Challenge</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              In 2024, the FRC game was to shoot "notes" into an elevated goal, as well as climb on a chain.
            </p>
          </CardContent>
        </Card>

        {/* Robot Design */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Robot Design</CardTitle>
            <CardDescription>Key Systems and Features</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Shooter and Pivot System</h3>
              <ul className="list-inside list-disc space-y-2 text-muted-foreground">
                <li>Home position scoring without pivoting for redundancy</li>
                <li>Pivoting capability for long-range shots</li>
                <li>Two brushless motors on an 18:24 overdrive for high-speed, accurate shooting</li>
                <li>Indexer to hold notes before shooting, allowing motors to reach optimal speed</li>
              </ul>

              <h3 className="text-lg font-semibold">Pivot Mechanism</h3>
              <ul className="list-inside list-disc space-y-2 text-muted-foreground">
                <li>Four brushless motors on a 40:1 reduction for quick angle adjustments</li>
                <li>Dual-purpose design: shooting accuracy and climbing capability</li>
                <li>Mounted on a 0.75" dead axle with roller bearings for robustness</li>
              </ul>

              <h3 className="text-lg font-semibold">Swerve Drivebase</h3>
              <p className="text-muted-foreground">
                Designed a swerve drive system for enhanced maneuverability and control during matches.
              </p>
            </div>
          </CardContent>
        </Card>
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Competition Awards</CardTitle>
            <CardDescription>Recognition of Technical Excellence</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-semibold">Autonomous Award</h3>
                <p className="text-muted-foreground">
                  Recognized for exceptional autonomous capabilities and reliable performance during the autonomous
                  period.
                </p>
              </div>
              <div>
                <h3 className="text-lg font-semibold">Quality Award</h3>
                <p className="text-muted-foreground">
                  Acknowledged for outstanding robot construction quality and robust mechanical design.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

